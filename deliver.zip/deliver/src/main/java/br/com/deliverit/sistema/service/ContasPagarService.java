package br.com.deliverit.sistema.service;

import br.com.deliverit.sistema.model.ContasPagar;
import br.com.deliverit.sistema.model.RegraAtraso;
import br.com.deliverit.sistema.repository.ContasPagarRepository;
import br.com.deliverit.sistema.repository.RegraAtrasoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.List;

@Service
public class ContasPagarService {

    @Autowired
    ContasPagarRepository contasPagarRepository;

    @Autowired
    RegraAtrasoRepository regraAtrasoRepository;

    public void addContas(ContasPagar contasPagar){

        Long qtdDiasAtraso = ((contasPagar.getDataPagamento().getTime() - contasPagar.getDataVencimento().getTime()) + 3600000)/86400000L;

        if(qtdDiasAtraso > 0) {
            RegraAtraso regraAtraso = regraAtrasoRepository.
                    findByDiasMaxGreaterThanEqualAndDiasMinLessThanEqual(qtdDiasAtraso, qtdDiasAtraso);
            if(regraAtraso != null) {
                Double valorOriginal = contasPagar.getValorOriginal();
                Double valorCorrigido = valorOriginal + (valorOriginal * (regraAtraso.getMulta() / 100)) +
                       (valorOriginal * ((regraAtraso.getJurosDia() * qtdDiasAtraso) / 100));
               contasPagar.setValorCorrigido(new BigDecimal(valorCorrigido,new MathContext(4)).doubleValue());
               contasPagar.setOidRegra(regraAtraso.getOidRegra());
               contasPagar.setQtdDiasAtraso(qtdDiasAtraso);
            }
        }else {
            contasPagar.setValorCorrigido(contasPagar.getValorOriginal());
            contasPagar.setQtdDiasAtraso(0L);
        }

        contasPagarRepository.save(contasPagar);
    }

    public List<ContasPagar> listAll(){
        return contasPagarRepository.findAll();
    }
}
