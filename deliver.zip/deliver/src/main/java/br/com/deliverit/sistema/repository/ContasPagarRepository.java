package br.com.deliverit.sistema.repository;

import br.com.deliverit.sistema.model.ContasPagar;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ContasPagarRepository extends MongoRepository<ContasPagar,ObjectId>{




}
