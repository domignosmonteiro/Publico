package br.com.deliverit.sistema.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Getter
@Setter
@Document(collection = "RegraAtraso")
public class RegraAtraso {

    @Id
    private Long oidRegra;

    private Long diasMin;

    private Long diasMax;

    private Double multa;

    private Double jurosDia;

    protected RegraAtraso(){}

    public RegraAtraso(Long diasMin, Long diasMax, Double multa, Double jurosDia) {
        this.diasMin = diasMin;
        this.diasMax = diasMax;
        this.multa = multa;
        this.jurosDia = jurosDia;
    }

    @Override
    public String toString() {
        return "RegraAtraso{" +
                "oidRegra=" + oidRegra +
                ", diasMin=" + diasMin +
                ", diasMax=" + diasMax +
                ", multa=" + multa +
                ", jurosDia=" + jurosDia +
                '}';
    }
}

