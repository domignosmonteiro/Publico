package br.com.deliverit.sistema.controller;

import br.com.deliverit.sistema.model.ContasPagar;
import br.com.deliverit.sistema.service.ContasPagarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/")
public class ContasPagarController {

    @Autowired
    ContasPagarService service;

    @RequestMapping(method = RequestMethod.GET)
    public String listaContas(Model model) {
        List<ContasPagar> listaContas = service.listAll();
        if (listaContas != null) {
            model.addAttribute("contas", listaContas);
        }
        return "listaContas";
    }

    @RequestMapping(method = RequestMethod.POST)
    public String adicionaConta(ContasPagar contasPagar) {
        if (validaCamposObrigatorios(contasPagar)) {
            service.addContas(contasPagar);
            return "redirect:/";
        }
        return "erro";
    }

    @GetMapping(path = "/add", produces= {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity add(@RequestParam String nome,
                              @RequestParam String valorPagamento,
                              @RequestParam @DateTimeFormat(pattern = "dd/MM/yyyy") Date dataVencimento,
                              @RequestParam @DateTimeFormat(pattern = "dd/MM/yyyy") Date dataPagamento) {

        ContasPagar contasPagar = new ContasPagar(nome,
                Double.valueOf(valorPagamento),
                dataVencimento,
                dataPagamento);

        if (validaCamposObrigatorios(contasPagar)) {
            service.addContas(contasPagar);
            return ResponseEntity.ok("Conta Adicionada com Sucesso!");
        }

        return ResponseEntity.ok("Campos Obrigatórios");
    }

    @GetMapping(path = "/listAll", produces= {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity listAll() {
        return ResponseEntity.ok(service.listAll());
    }

    public boolean validaCamposObrigatorios(ContasPagar conta){
        return conta != null && !StringUtils.isEmpty(conta.getNomeConta()) &&
                !StringUtils.isEmpty(conta.getValorOriginal()) &&
                conta.getDataVencimento() != null && conta.getDataPagamento() != null;
    }
}
