package br.com.deliverit.sistema;

import br.com.deliverit.sistema.model.RegraAtraso;
import br.com.deliverit.sistema.repository.RegraAtrasoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

@SpringBootApplication
public class Application {

    private static final Logger log = LoggerFactory.getLogger(Application.class);

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    //Adiciona as regras de juros no banco ao inicializar a aplicação
    //Estou utilizando o banco h2
    @Bean
    public CommandLineRunner demo(RegraAtrasoRepository repository) {
        return (args) -> {
            repository.save(new RegraAtraso(1L,3L, 2D, 0.1D));
            repository.save(new RegraAtraso(4L,5L, 3D, 0.2D));
            repository.save(new RegraAtraso(6L,999999999L, 5D, 0.3D));
        };
    }

    /*@Bean
    public DataSource dataSource(){
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("mongodb.jdbc.MongoDriver");
        dataSource.setUrl("jdbc:mongo://127.0.0.1:27017/bancosistema");
        return dataSource;
    }*/
}
