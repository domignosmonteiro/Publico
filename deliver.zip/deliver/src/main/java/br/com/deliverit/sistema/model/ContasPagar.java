package br.com.deliverit.sistema.model;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@Document(collection = "ContasPagar")
public class ContasPagar implements Serializable {

    public ContasPagar(String nomeConta, Double valorOriginal, Date dataVencimento, Date dataPagamento) {
        this.nomeConta = nomeConta;
        this.valorOriginal = valorOriginal;
        this.dataVencimento = dataVencimento;
        this.dataPagamento = dataPagamento;
    }

    @Id
    private Long oidContasPagar;

    private String nomeConta;

    private Double valorOriginal;

    private Double valorCorrigido;

    private Date dataVencimento;

    private Date dataPagamento;

    private Long qtdDiasAtraso;

    private Long oidRegra;

}
