package br.com.deliverit.sistema.repository;

import br.com.deliverit.sistema.model.RegraAtraso;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface RegraAtrasoRepository extends MongoRepository<RegraAtraso, ObjectId> {

    RegraAtraso findByDiasMaxGreaterThanEqualAndDiasMinLessThanEqual(Long diasMin, Long diasMax);
}
